<?php
/**
 * Plugin Name: Fusion Builder Custom Recent Posts Addon
 * Plugin URI: https://github.com/Theme-Fusion/Fusion-Builder-Sample-Add-On
 * Description: Custom recent posts element using this sample addon for fusion builder.
 * Version: 1.2
 * Author: ThemeFusion
 * Author URI: https://www.theme-fusion.com
 *
 * @package Sample Addon for Fusion Builder
 */

// Plugin Folder Path.
if ( ! defined( 'RECENT_POSTS_PLUGIN_DIR' ) ) {
	define( 'RECENT_POSTS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

register_activation_hook( __FILE__, array( 'Post_Slider_Addon_FB', 'activation' ) );

if ( ! class_exists( 'Post_Slider_Addon_FB' ) ) {

	// Include the main plugin class.
	include_once wp_normalize_path( RECENT_POSTS_PLUGIN_DIR . '/inc/class-sample-addon-fb.php' );

	/**
	 * Instantiate Post_Slider_Addon_FB class.
	 */
	function custom_recent_posts_addon_activate() {
		Post_Slider_Addon_FB::get_instance();
	}

	add_action( 'wp_loaded', 'custom_recent_posts_addon_activate', 10 );
}

/**
 * Map shortcode to Fusion Builder.
 *
 * @since 1.0
 */
function map_custom_recent_posts_addon_with_fb() {
		$builder_status = function_exists( 'is_fusion_editor' ) && is_fusion_editor();
	// Map settings for parent shortcode.
	fusion_builder_map(
		array(
			'name'          => esc_attr__( 'Custom Recent Posts', 'fusion-builder' ),
			'shortcode'     => 'fusion_custom_recent_posts',
			'icon'          => 'far fa-newspaper',
			'generator_only'=> true,
			'preview'       => RECENT_POSTS_PLUGIN_DIR . 'js/preview/sample-addon-preview.php',
			'preview_id'    => 'fusion-builder-block-module-sample-addon-preview-template',
			'params'        => array(
				array(
					'type'        => 'multiple_select',
						'heading'     => esc_attr__( 'Categories', 'fusion-builder' ),
						'placeholder' => esc_attr__( 'Categories', 'fusion-builder' ),
						'description' => esc_attr__( 'Select a category or leave blank for all.', 'fusion-builder' ),
						'param_name'  => 'cat_slug',
						'value'       => $builder_status ? fusion_builder_shortcodes_categories( 'category' ) : [],
						'default'     => '',
						'callback'    => [
							'function' => 'fusion_ajax',
							'action'   => 'get_fusion_recent_posts',
							'ajax'     => true,
						],
				),
				array(
					'type'        => 'range',
					'heading'     => esc_attr__( 'Number of Columns', 'fusion-builder' ),
					'description' => esc_attr__( 'Select the number of columns to display.', 'fusion-builder' ),
					'param_name'  => 'columns',
					'value'       => '3',
					'min'         => '1',
					'max'         => '6',
					'step'        => '1',
				),
				array(
					'type'        => 'multiple_select',
					'heading'     => esc_attr__( 'Post Status', 'fusion-builder' ),
					'placeholder' => esc_attr__( 'Post Status', 'fusion-builder' ),
					'description' => esc_attr__( 'Select the status(es) of the posts that should be included or leave blank for published only posts.', 'fusion-builder' ),
					'param_name'  => 'post_status',
					'value'       => [
						'publish' => esc_attr__( 'Published' ),
						'draft'   => esc_attr__( 'Drafted' ),
						'future'  => esc_attr__( 'Scheduled' ),
						'private' => esc_attr__( 'Private' ),
						'pending' => esc_attr__( 'Pending' ),
					],
					'default'     => '',
					'callback'    => [
						'function' => 'fusion_ajax',
						'action'   => 'get_fusion_recent_posts',
						'ajax'     => true,
					],
				),
				array(
					'type'        => 'range',
					'heading'     => esc_attr__( 'Posts Per Page', 'fusion-builder' ),
					'description' => esc_attr__( 'Select number of posts per page.  Set to -1 to display all.', 'fusion-builder' ),
					'param_name'  => 'number_posts',
					'value'       => '6',
					'min'         => '-1',
					'max'         => '25',
					'step'        => '1',
					'callback'    => [
						'function' => 'fusion_ajax',
						'action'   => 'get_fusion_recent_posts',
						'ajax'     => true,
					],
			),
                array (
                    'type'        => 'multiple_select',
                    'heading'     => esc_attr__( 'Exclude Categories', 'fusion-builder' ),
                    'placeholder' => esc_attr__( 'Categories', 'fusion-builder' ),
                    'description' => esc_attr__( 'Select a category to exclude.', 'fusion-builder' ),
                    'param_name'  => 'exclude_cats',
                    'value'       => $builder_status ? fusion_builder_shortcodes_categories( 'category' ) : [],
                    'default'     => '',
                    'callback'    => [
                        'function' => 'fusion_ajax',
                        'action'   => 'get_fusion_recent_posts',
                        'ajax'     => true,
                    ],
                ),
			),
		)
	);

    // Example of how to add or modify options to existing element in Fusion Builder.
    if ( function_exists( 'fusion_builder_update_element' ) ) {
        fusion_builder_update_element( 'fusion_button', 'color', array( 'cyan' => esc_attr__( 'New - Cyan', 'fusion-builder' ) ) );
        fusion_builder_update_element( 'fusion_button', 'color', array( 'black' => esc_attr__( 'New - Black', 'fusion-builder' ) ) );
        fusion_builder_update_element( 'fusion_button', 'element_content', 'Sample Button' );
    }

}

add_action( 'fusion_builder_before_init', 'map_custom_recent_posts_addon_with_fb', 11 );

/**
 * Include options from options folder.
 *
 * @access public
 * @since 1.1
 * @return void
 */
function fusion_init_custom_recent_posts_sample_options() {

	// Early exit if the Fusion_Element class does not exist.
	if ( ! class_exists( 'Fusion_Element' ) ) {
		return;
	}

	// Include the file.
	require_once 'options/class-sample-element-options.php';

	// Instantiate the object.
	new Custom_Recent_Posts_Sample_Element_Options();
}

add_action( 'fusion_builder_shortcodes_init', 'fusion_init_custom_recent_posts_sample_options', 1 );

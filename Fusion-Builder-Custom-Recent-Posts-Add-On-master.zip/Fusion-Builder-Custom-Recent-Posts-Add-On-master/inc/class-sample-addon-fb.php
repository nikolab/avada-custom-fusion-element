<?php
/**
 * The main plugin class Post_Slider_Addon_FB
 *
 * @since 1.2
 * @package Sample Addon for Fusion Builder
 */

/**
 * The main plugin class.
 */
class Post_Slider_Addon_FB {

	/**
	 * The one, true instance of this object.
	 *
	 * @static
	 * @access private
	 * @since 1.0
	 * @var object
	 */
	private static $instance;

	/**
	 * Creates or returns an instance of this class.
	 *
	 * @static
	 * @access public
	 * @since 1.0
	 */
	public static function get_instance() {

		// If an instance hasn't been created and set to $instance create an instance and set it to $instance.
		if ( null === self::$instance ) {
			self::$instance = new Post_Slider_Addon_FB();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 1.0
	 */
	public function __construct() {

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

		add_shortcode( 'fusion_custom_recent_posts', array( $this, 'fusion_custom_recent_posts' ) );

		// Add new settings field to Fusion Builder.
		add_filter( 'fusion_builder_fields', array( $this, 'add_new_field' ) );

	}

	/**
	 * Add new radio_image setting field to Fusion Builder.
	 *
	 * @access public
	 * @since 1.1
	 * @param array $fields The array of fields added with filter.
	 * @return array
	 */
	public function add_new_field( $fields ) {
		$fields[] = array( 'radio_image', RECENT_POSTS_PLUGIN_DIR . 'fields/radio_image.php' );
		return $fields;
	}

	/**
	 * Enqueue scripts & styles.
	 *
	 * @access public
	 * @since 1.0
	 */
	public function enqueue_scripts() {

        wp_enqueue_script( 'mdernizr-js', RECENT_POSTS_PLUGIN_DIR . 'js/mdernizr.custom.js' );
		wp_enqueue_style( 'recent-posts', RECENT_POSTS_PLUGIN_DIR . 'css/recent-posts.css' );

	}

	/**
	 * Returns the content.
	 *
	 * @access public
	 * @since 1.0
	 * @param array  $atts    The attributes array.
	 * @param string $content The content.
	 * @return string
	 */
	public function fusion_custom_recent_posts( $atts ) {

        global $fusion_settings;


        //add custom image size for post thumbnails
        add_theme_support( 'post-thumbnails' );
        add_image_size( 'custom-recent-post-img', 284, 200 );

        // Check for cats to exclude; needs to be checked via exclude_cats param
        // and '-' prefixed cats on cats param, exclution via exclude_cats param.
        $cats_to_exclude = explode( ',', $atts['exclude_cats'] );
        if ( $cats_to_exclude ) {
            foreach ( $cats_to_exclude as $cat_to_exclude ) {
                $id_obj = get_category_by_slug( $cat_to_exclude );
                if ( $id_obj ) {
                    $cats_id_to_exclude[] = $id_obj->term_id;
                }
            }
            if ( isset( $cats_id_to_exclude ) && $cats_id_to_exclude ) {
                $atts['category__not_in'] = $cats_id_to_exclude;
            }
        }

        // Setting up cats to be used and exclution using '-' prefix on cats param; transform slugs to ids.
        $cat_ids    = '';
        $categories = explode( ',', $atts['cat_slug'] );
        if ( isset( $categories ) && $categories ) {
            foreach ( $categories as $category ) {
                if ( $category ) {
                    $cat_obj = get_category_by_slug( $category );
                    if ( isset( $cat_obj->term_id ) ) {
                        $cat_ids .= ( 0 === strpos( $category, '-' ) ) ? '-' . $cat_obj->cat_ID . ',' : $cat_obj->cat_ID . ',';
                    }
                }
            }
        }

        $atts['cat'] = substr( $cat_ids, 0, -1 ) . $atts['cat_id'];

        // query recent posts
		$the_query = new WP_Query( array(
		  	'category_name' => $atts['cat_slug'],
			'post_status'   => $atts['post_status'],
			'posts_per_page'   => $atts['number_posts'],
            'category__not_in' => $atts['category__not_in'],

		));

		// set columns
        $columns = 3;
        if ( $atts['columns'] ) {
            $columns = 12 / $atts['columns'];
        }

        $attr = [
            'class' => 'post fusion-column column col col-lg-' . $columns . ' col-md-' . $columns . ' col-sm-' . $columns . '',
            'style' => '',
        ];

        if ( '5' === $atts['columns'] || 5 === $atts['columns'] ) {
            $attr['class'] = 'post fusion-column column col-lg-2 col-md-2 col-sm-2';
        }

        $i = 1;

		?>

    <div class="fusion-recent-posts fusion-recent-posts-<?php echo $i; ?> avada-container layout-default layout-columns-<?php echo $atts['columns']; ?>">
    <section class="fusion-columns columns fusion-columns-<?php echo $atts['columns']; ?> columns-<?php echo $atts['columns']; ?>">

		<?php if ( $the_query->have_posts() ) : ?>

                <?php while ( $the_query->have_posts() ) : $the_query->the_post();

                        $permalink = get_permalink( get_the_ID() );
                        $cats = get_the_category();
                        $cat_link = get_category_link( $cats[0]->term_id );
                        $cat_name = $cats[0]->name;

                    ?>
                     <article class="<?php echo $attr['class']; ?>">
                        <div class="recent-posts-content">
                            <a href="<?php echo $permalink; ?>">
                            <?php the_post_thumbnail( 'custom-recent-post-img' ); ?>
                            </a>
                            <h6 class="post-category"><a href="<?php echo $cat_link; ?>"><?php echo $cat_name; ?></a></h6>
                            <h4 class="entry-title"><a href="<?php echo $permalink; ?>"><?php the_title(); ?></a></h4>
                            <p class="post-meta-date">
                                <svg id="Group_537" data-name="Group 537" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="18" height="18.902" viewBox="0 0 18 18.902">
                                    <defs>
                                        <clipPath id="clip-path">
                                            <path id="Path_309" data-name="Path 309" d="M0,9.265H18v-18.9H0Z" transform="translate(0 9.637)"/>
                                        </clipPath>
                                    </defs>
                                    <g id="Group_536" data-name="Group 536" transform="translate(0 0)" clip-path="url(#clip-path)">
                                        <g id="Group_535" data-name="Group 535" transform="translate(-0.001 0)">
                                            <path id="Path_308" data-name="Path 308" d="M8.823,8.5V-4.618A1.554,1.554,0,0,0,7.266-6.175H5.375V-8.382a.463.463,0,0,0-.926,0v2.207H-4.8V-8.382A.463.463,0,0,0-5.729-8.4v2.209H-7.62A1.553,1.553,0,0,0-9.177-4.641V8.5A1.554,1.554,0,0,0-7.62,10.06H7.266A1.554,1.554,0,0,0,8.823,8.5m-.9-10.009H-8.253V-4.618A.657.657,0,0,1-7.6-5.271h1.893v1.62a.463.463,0,0,0,.926,0v-1.62h9.23v1.62a.463.463,0,0,0,.926,0v-1.62H7.266a.657.657,0,0,1,.653.653Zm0,10.031a.64.64,0,0,1-.653.632H-7.62A.657.657,0,0,1-8.273,8.5V-.581H7.919Zm-2.4-2.25a.779.779,0,1,0-.779.779.779.779,0,0,0,.779-.779m0-3.617a.779.779,0,1,0-.779.779.779.779,0,0,0,.779-.779M.6,6.274A.779.779,0,0,0-.178,5.5a.779.779,0,0,0-.777.779.779.779,0,0,0,.777.779A.779.779,0,0,0,.6,6.274m0-3.617a.779.779,0,0,0-.779-.779.779.779,0,0,0-.777.779.779.779,0,0,0,.777.779A.779.779,0,0,0,.6,2.657M-4.319,6.274A.779.779,0,0,0-5.1,5.5a.779.779,0,0,0-.779.779.779.779,0,0,0,.779.779.779.779,0,0,0,.779-.779m0-3.617A.779.779,0,0,0-5.1,1.878a.779.779,0,0,0-.779.779.779.779,0,0,0,.779.779.779.779,0,0,0,.779-.779" transform="translate(9.177 8.843)"/>
                                        </g>
                                    </g>
                                </svg>
                                <span class="meta-date"><?php echo get_the_date( 'd/m/y' ); ?></span>
                            </p>

                            <a class="findout-more-recent-posts" href="<?php echo $permalink; ?>">find out more <i class="fas fa-caret-right"></i></a>
                        </div>
                     </article>
                    <?php
                    endwhile;
                    wp_reset_postdata();
                    $i++;
                    ?>

                    <?php
                    endif;
                    ?>
    </section>
    </div>
		<?php

	} // end the query


	/**
	 * Processes that must run when the plugin is activated.
	 *
	 * @static
	 * @access public
	 * @since 1.0
	 */
	public static function activation() {
		if ( ! class_exists( 'FusionBuilder' ) ) {
			echo '<style type="text/css">#error-page > p{display:-webkit-flex;display:flex;}#error-page img {height: 120px;margin-right:25px;}.fb-heading{font-size: 1.17em; font-weight: bold; display: block; margin-bottom: 15px;}.fb-link{display: inline-block;margin-top:15px;}.fb-link:focus{outline:none;box-shadow:none;}</style>';
			$message = '<span><span class="fb-heading">Sample Addon for Fusion Builder could not be activated</span>';
			$message .= '<span>Sample Addon for Fusion Builder can only be activated if Fusion Builder 1.0 or higher is activated. Click the link below to install/activate Fusion Builder, then you can activate this plugin.</span>';
			$message .= '<a class="fb-link" href="' . admin_url( 'admin.php?page=avada-plugins' ) . '">' . esc_attr__( 'Go to the Avada plugin installation page', 'Avada' ) . '</a></span>';
			wp_die( wp_kses_post( $message ) );
		} else {

            // Example of adding custom saved elements to the library on plugin activation.
            require_once wp_normalize_path( RECENT_POSTS_PLUGIN_DIR . '/saved-templates/saved-elements.php' );
		}
	}
}

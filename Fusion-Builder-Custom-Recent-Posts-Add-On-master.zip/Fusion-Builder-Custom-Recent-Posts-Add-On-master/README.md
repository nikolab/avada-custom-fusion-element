# Fusion Builder Sample Add-On
Fusion Builders sample add on for developers

This addon is based on Cordops blueprint for "Quotes Rotator" here - http://tympanus.net/Blueprints/QuotesRotator/ and works fine with Avada version 5.1 and above

## Developer Documentation
You can access our developer documentation for Fusion Builder here - https://theme-fusion.com/documentation/fusion-builder/

## Please Note: This is just a sample add-on for developers to get started with our API. Please do not use it on your live site, as it may cause issues.
